var date= new Date();

if(date.getDate()<=15)
{
    document.write("First fifteen days !!!");
}
else
{
    document.write("Last fifteen days !!!");
}