var date= new Date();

var m=["Sun", "Mon", "Tue", "Wed", "Thr", "Fri", "Sat"];

document.write("Today is = "+m[date.getDay()]);