var date= new Date();

var m=["Jan", "Feb", "March", "April", "May", "June", "July", "August", "Sept", "Oct", "Nov", "Dec"];

document.write("current month = "+m[date.getMonth()]);