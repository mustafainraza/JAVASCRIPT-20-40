var date= new Date();

document.write("Date = "+date);