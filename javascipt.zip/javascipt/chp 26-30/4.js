var dice=Math.random(dice);
dice=Math.ceil(dice*6);

document.write("Random Dice value : "+dice);