var val=prompt("Enter your weight : ");

val=parseFloat(val);

document.write("The weight of user is "+val+" Kilograms");