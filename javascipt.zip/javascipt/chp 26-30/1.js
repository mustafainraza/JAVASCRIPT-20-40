var n1=prompt("Enter any number : ");
n1=Math.abs(n1);
document.write("number : "+n1);
document.write("<br> round off : "+Math.round(n1));
document.write("<br> floor : "+Math.floor(n1));
document.write("<br> ceil : "+Math.ceil(n1));
