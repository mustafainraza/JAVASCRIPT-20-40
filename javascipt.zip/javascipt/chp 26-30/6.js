var rand=Math.random(rand);
rand=Math.ceil(rand*100);

document.write("Random value from 1-100 : "+rand);