var n1=prompt("Enter any number : ");
var abs =Math.abs(n1);
document.write("absolute of "+n1+" is "+abs);