function getdate()
{
    var date= new Date();
    document.write(date);
}

getdate();