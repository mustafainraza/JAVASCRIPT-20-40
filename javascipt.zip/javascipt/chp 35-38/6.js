var first=prompt("enter first number : ");
function sqrt1()
{
    let sqr=first*first;
    document.write("square of "+first+" = "+sqr);
}

sqrt1();