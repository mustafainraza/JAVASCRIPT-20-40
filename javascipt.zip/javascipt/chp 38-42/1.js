var a=2,b=5;

function power(a,b)
{
    var c=Math.pow(a,b);
    document.write(a+" ^ "+b+" = "+c);
}

power(a,b);