var first=prompt("enter first name : ");
var last=prompt("enter last name : ");

var fullname=first.concat(last);

alert("HI "+fullname);