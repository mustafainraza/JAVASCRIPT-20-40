var message = "Ali and Sami are best friends. They play cricket and football together.";

var message=message.replace(/and/g,'&');

alert("done = "+ message);