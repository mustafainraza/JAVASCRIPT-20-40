var word="Pakistani";
var indexofn=word.indexOf('n');

alert("index of n= "+ indexofn);