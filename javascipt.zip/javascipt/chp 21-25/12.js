var num=35.36;

document.write("Number : "+num);

num=num.toString().replace('.','');

document.write("<br> Result : "+num);