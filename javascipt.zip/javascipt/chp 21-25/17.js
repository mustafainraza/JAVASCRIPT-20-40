var str="Pakistan";

document.write(str[str.length-1])