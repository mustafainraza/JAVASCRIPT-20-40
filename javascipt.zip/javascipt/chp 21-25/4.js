var word="Hello World";
var indexofn=word.lastIndexOf('l')

alert("Last index of l= "+ indexofn);