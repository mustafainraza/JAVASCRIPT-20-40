var first=prompt("enter first name : ");
var last=prompt("enter last name : ");

var fullname=first.toString()+last.toString();

alert("HI "+fullname);