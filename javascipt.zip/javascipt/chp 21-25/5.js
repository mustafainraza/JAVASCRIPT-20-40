var word="Pakistani";
var indexofn=word.charAt(3);

alert("character at 3rd index is = "+ indexofn);