var name1="hyderabad";

name1=name1.replace("hyder","Islam");

alert("name is "+name1);