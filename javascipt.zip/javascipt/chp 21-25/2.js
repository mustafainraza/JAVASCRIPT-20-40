var name1=prompt("Enter phone name : ");

alert("LENGTH = " + name1.length);