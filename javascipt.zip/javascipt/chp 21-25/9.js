var str="972";
document.write("number = "+str);
document.write("<br> type = ",typeof(str));

str=parseInt(str);

document.write("<br> number = "+str);
document.write("<br> type = ",typeof(str));

