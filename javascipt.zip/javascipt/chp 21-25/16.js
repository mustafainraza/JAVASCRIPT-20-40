var str="University of Karachi";

str=Array.from(str);

for(var i=0;i<str.length;i++)
{
    document.write(str[i],"<br>");
}