var word=prompt("Enter a word : ");

document.write(word);

document.write("<br>"+word.toUpperCase());